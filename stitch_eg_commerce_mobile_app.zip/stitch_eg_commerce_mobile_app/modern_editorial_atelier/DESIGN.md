---
name: Modern Editorial Atelier
colors:
  surface: '#fbf9f6'
  surface-dim: '#dbdad7'
  surface-bright: '#fbf9f6'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f5f3f0'
  surface-container: '#efeeeb'
  surface-container-high: '#eae8e5'
  surface-container-highest: '#e4e2df'
  on-surface: '#1b1c1a'
  on-surface-variant: '#47464b'
  inverse-surface: '#30312f'
  inverse-on-surface: '#f2f0ed'
  outline: '#77767b'
  outline-variant: '#c8c5cb'
  surface-tint: '#5f5e61'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#1b1b1e'
  on-primary-container: '#858387'
  inverse-primary: '#c8c5ca'
  secondary: '#9d4229'
  on-secondary: '#ffffff'
  secondary-container: '#fd8c6d'
  on-secondary-container: '#74240e'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#2c1600'
  on-tertiary-container: '#a77b4e'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e4e1e6'
  primary-fixed-dim: '#c8c5ca'
  on-primary-fixed: '#1b1b1e'
  on-primary-fixed-variant: '#47464a'
  secondary-fixed: '#ffdbd1'
  secondary-fixed-dim: '#ffb4a1'
  on-secondary-fixed: '#3c0800'
  on-secondary-fixed-variant: '#7e2b15'
  tertiary-fixed: '#ffdcbd'
  tertiary-fixed-dim: '#f0bd8b'
  on-tertiary-fixed: '#2c1600'
  on-tertiary-fixed-variant: '#623f18'
  background: '#fbf9f6'
  on-background: '#1b1c1a'
  surface-variant: '#e4e2df'
typography:
  headline-xl:
    fontFamily: Noto Serif
    fontSize: 48px
    fontWeight: '400'
    lineHeight: 60px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Noto Serif
    fontSize: 32px
    fontWeight: '400'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Noto Serif
    fontSize: 36px
    fontWeight: '400'
    lineHeight: 48px
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Noto Serif
    fontSize: 26px
    fontWeight: '400'
    lineHeight: 34px
  headline-md:
    fontFamily: Noto Serif
    fontSize: 28px
    fontWeight: '500'
    lineHeight: 36px
  headline-sm:
    fontFamily: IBM Plex Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: IBM Plex Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 30px
  body-md:
    fontFamily: IBM Plex Sans
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: IBM Plex Sans
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: IBM Plex Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.04em
  label-md:
    fontFamily: IBM Plex Sans
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.06em
  label-sm:
    fontFamily: IBM Plex Sans
    fontSize: 10px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.08em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 0.75rem
  margin: 3rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system embodies quiet luxury and modern Middle Eastern sophistication. Designed specifically for high-end fashion, curated designer drops, and independent creator storefronts, the aesthetic fuses contemporary editorial minimalism with subtle warmth drawn from Egyptian architectural forms and earth tones.

### Personality & Tone
- **Curated & Restrained:** Generous negative space, uncompromising typography, and zero visual clutter allow garments, editorial photography, and textiles to remain the focal point.
- **Warm Architectural Precision:** Strict linear structure balanced by sun-baked mineral tones—sandstone, clay, and terracotta—against crisp linen surfaces.
- **Bilingual & Culturally Fluid:** Native right-to-left (RTL) architecture for Arabic with seamless bilingual pairing for English typographic balance.

### Target Audience
Discerning fashion collectors, luxury shoppers, and regional creators who value craftsmanship, editorial storytelling, and effortless transactional clarity.

## Colors

The color palette centers on high-contrast, editorial quiet luxury. It relies on a radiant linen background, deep obsidian ink for pristine legibility, and architectural mineral accents.

### Color Tokens
- **Primary Ink (`#18181B`):** Deep carbon black. Used for display typography, prominent structural lines, primary interaction states, and solid high-contrast call-to-actions.
- **Secondary Accent - Terracotta (`#B45339`):** A warm, refined Egyptian desert clay tone. Used strictly for intentional focal points: bag badges, limited drop tags, curated collection highlights, and active micro-indicators.
- **Tertiary Accent - Sand Stone (`#D4A373`):** Warm mineral beige used for subtle backdrops, premium member badges, delicate active states, and tonal borders.
- **Neutral Surface - Linen (`#FAF8F5`):** A soft, warm off-white canvas that reduces eye fatigue compared to pure clinical white while offering an elevated gallery feel.
- **Borders & Dividers:** Use muted zinc borders (`#E4E0D8` in light contexts) calibrated to 0.75px–1px hairline precision to honor editorial grid lines.

## Typography

The typography strategy unites literary distinction with structural clarity across Arabic and Latin scripts.

### Typographic Harmony & Script Rules
- **Display & Headlines:** `Noto Serif` evokes classical craftsmanship, high-fashion broadsheets, and timeless sophistication. Paired alongside Noto Naskh Arabic or IBM Plex Sans Arabic for editorial titles.
- **Functional Interface & Body:** `IBM Plex Sans` (including IBM Plex Sans Arabic) handles operational information, prices, sizing tables, and user reviews with structured legibility.
- **RTL Baseline Alignment:** For Arabic text runs (`dir="rtl"`), font size stays identical while optical line-height increases by 10-15% to support complex Arabic ascenders and descenders without clipping.
- **Numerals:** Standardize on Western Arabic numerals (1, 2, 3) or Eastern Arabic numerals (١، ٢، ٣) consistently within regional locale settings, rendered using tabular figures for checkout totals and inventory numbers.

## Layout & Spacing

This design system uses a fluid 12-column architectural grid on desktop and tablet, shifting dynamically to a single- or double-column structure on mobile.

### Grid & Responsiveness
- **Desktop (1280px+):** 12 columns, `margin: 3rem`, `gutter: 1.5rem`. Maximum container width is capped at 1440px to ensure photography and typography retain an intimate boutique proportion.
- **Tablet (768px – 1279px):** 8 columns, `margin: 2rem`, `gutter: 1rem`.
- **Mobile (below 768px):** 4 columns (or 2 structural catalog lanes), `margin-mobile: 1.25rem`, `gutter-mobile: 0.75rem`.

### Spacing Philosophy
- Whitespace functions as a structural element rather than empty canvas. Generous gaps around product imagery (`space-xl`) build a sense of calm and exclusivity.
- Micro-spacing (`space-xs` and `space-sm`) governs tightly paired metadata such as garment care tags, designer names, currency symbols, and size labels.
- Symmetrical logical padding (`padding-inline-start` and `padding-inline-end`) must be enforced across all responsive containers to maintain mirror symmetry across LTR and RTL viewports.

## Elevation & Depth

Visual hierarchy relies on low-contrast outlines, tonal surface shifts, and gossamer ambient shadows rather than heavy skeuomorphic drop shadows.

### Elevation Principles
- **Tier 0 (Base Canvas):** Background tone `#FAF8F5`. All content anchors flat to this neutral linen ground.
- **Tier 1 (Cards & Modules):** Surface shifts to pure `#FFFFFF` bounded by a 1px ghost stroke of `#E4E0D8`. No shadow in resting state.
- **Tier 2 (Hover & Focus States):** Subtle ambient diffusion: `box-shadow: 0 8px 24px -4px rgba(24, 24, 27, 0.05)`. Sharp outline softens into an obsidian tint.
- **Tier 3 (Floating Navbars, Drawers & Modals):** Off-canvas cart drawers and quick-view modals employ backdrop filters (`backdrop-filter: blur(12px)`) with 85% opacity surface fills (`rgba(250, 248, 245, 0.85)`) paired with ultra-diffuse shadows: `0 20px 48px -12px rgba(24, 24, 27, 0.12)`.

## Shapes

The design system employs a soft, architectural geometry (Roundedness Level 1). 

- **Base Radius (0.25rem / 4px):** Applied to form fields, tags, micro-badges, and product variant swatches.
- **Medium / Card Radius (`rounded-lg` - 0.5rem / 8px):** Standard for product cards, visual banners, dialog boxes, and image viewports.
- **Large Radius (`rounded-xl` - 0.75rem / 12px):** Reserved for modal overlays, drawer sheets, and bottom navigation modules.
- **Buttons & Icon Discs:** Buttons maintain a tailored 0.25rem to 0.5rem radius to avoid looking casual or toy-like, leaving pill treatments strictly for floating customer-support triggers and quantity adjusters.

## Components

### Buttons
- **Primary Action:** Solid `#18181B` fill with `#FAF8F5` typography. Minimalist, uppercase or tracked label, 48px height for effortless mobile touch targets. Subtle scale transition (`scale(0.99)`) on tap.
- **Secondary Action:** Transparent fill with a crisp 1px border (`#18181B`) and `#18181B` typography.
- **Tertiary / Mineral:** Warm Terracotta fill (`#B45339`) reserved exclusively for decisive conversion steps: "Place Order" or "Unlock Drop".

### Product Cards
- Clean vertical stack: High-resolution imagery (aspect-ratio 3:4 or 4:5), 0.5rem corner radius, hairline 1px border.
- Floating designer attribution in `label-sm`, product title in `body-md` (Noto Serif), and price formatted in tabular `IBM Plex Sans`.
- Wishlist icon placed at logical inline-end (top-left in RTL, top-right in LTR) with smooth 150ms opacity transition on hover.

### Inputs & Form Fields
- Minimalist floating or top-aligned labels.
- Background in pure white or translucent linen, flanked by a 1px border in `#E4E0D8`. Focus state transitions to a solid `#18181B` border with zero outline ring clutter.
- Clear error states communicated through muted terracotta/carmine text, accompanied by an explicit inline explanation icon.

### Selection Controls (Checkboxes & Radios)
- Geometric, square checkboxes with 2px corner radius; circular radios.
- Unchecked: 1.5px border in `#A1A1AA`.
- Checked: Solid `#18181B` fill containing a sharp white check or inner dot.

### Editorial Badges & Chips
- Curated attributes (e.g., "Handcrafted in Cairo", "Egyptian Cotton", "Archival Drop") styled with 0.25rem radius, `#FAF8F5` background, 1px `#E4E0D8` outline, and 11px uppercase label font.

### RTL Navigation & Drawers
- Mobile navigation drawers and shopping bags slide in from the logical end (`right` in LTR, `left` in RTL).
- Back-arrow indicators and pagination carousels automatically flip orientation using CSS logical properties (`transform: scaleX(-1)` for RTL context icons).